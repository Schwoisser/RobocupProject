

class BeatDetector:
    def __init__(self, state):
        self.state = state

    def changeState(new_state):
        #send some stuff to dance loop
        self.state = new_state